JS_GENERATORS <- "odin"
JS_INSTANCES <- "instances"
