library(testthat)
library(odin.js)

test_check("odin.js")
