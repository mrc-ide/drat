library(testthat)
library(storr)

test_check("storr")
