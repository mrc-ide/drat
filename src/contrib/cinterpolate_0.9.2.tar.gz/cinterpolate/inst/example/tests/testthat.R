library(testthat)
library(example)

test_check("example")
