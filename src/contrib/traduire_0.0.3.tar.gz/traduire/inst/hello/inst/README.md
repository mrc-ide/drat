The translations in the [`traduire.json`](traduire.json) file have come from http://helloworldcollection.de/#Human
