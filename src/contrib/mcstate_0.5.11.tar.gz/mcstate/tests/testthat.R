library(testthat)
library(mcstate)

test_check("mcstate")
