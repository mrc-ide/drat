deriv(y) <- r
initial(y) <- 1
r <- 2
