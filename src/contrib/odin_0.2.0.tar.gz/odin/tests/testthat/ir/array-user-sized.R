initial(x[]) <- 1
deriv(x[]) <- r[i]
r[] <- user()
dim(r) <- user()
dim(x) <- length(r)
