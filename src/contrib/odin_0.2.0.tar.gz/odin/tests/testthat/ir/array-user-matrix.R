initial(y[, ]) <- 1
deriv(y[, ]) <- y[i, j] * r[i, j]
dim(y) <- c(2, 3)
dim(r) <- c(2, 3)
r[, ] <- user()
