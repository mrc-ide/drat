initial(x[]) <- 1
initial(y) <- 2
deriv(x[]) <- r[i]
deriv(y) <- n
r[] <- i
n <- 3
dim(r) <- n
dim(x) <- n
