initial(x[]) <- 1
deriv(x[]) <- r[i]
r[] <- user()
n <- 3
dim(r) <- n
dim(x) <- n
