This is the data available in this application
