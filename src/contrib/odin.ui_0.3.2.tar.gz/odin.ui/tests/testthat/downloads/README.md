Download file used by automated testing
