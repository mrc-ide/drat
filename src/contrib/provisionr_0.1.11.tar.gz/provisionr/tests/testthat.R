library(testthat)
library(provisionr)

test_check("provisionr")
