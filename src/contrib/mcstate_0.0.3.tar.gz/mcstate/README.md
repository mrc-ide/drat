## mcstate <img src='man/figures/logo.png' align="right" height="139" />

<!-- badges: start -->
[![Project Status: Concept – Minimal or no implementation has been done yet, or the repository is only intended to be a limited example, demo, or proof-of-concept.](https://www.repostatus.org/badges/latest/concept.svg)](https://www.repostatus.org/#concept)
[![Build Status](https://travis-ci.com/mrc-ide/mcstate.svg?branch=master)](https://travis-ci.com/mrc-ide/mcstate)
[![CodeFactor](https://www.codefactor.io/repository/github/mrc-ide/mcstate/badge)](https://www.codefactor.io/repository/github/mrc-ide/mcstate)
[![codecov.io](https://codecov.io/github/mrc-ide/mcstate/coverage.svg?branch=master)](https://codecov.io/github/mrc-ide/mcstate?branch=master)
<!-- badges: end -->

## License

MIT © Imperial College of Science, Technology and Medicine
