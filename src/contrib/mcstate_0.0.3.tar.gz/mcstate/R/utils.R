`%||%` <- function(a, b) { # nolint
  if (is.null(a)) b else a
}


mcstate_file <- function(path) {
  system.file(path, package = "mcstate", mustWork = TRUE)
}


vnapply <- function(x, fun, ...) {
  vapply(x, fun, numeric(1), ...)
}


squote <- function(x) {
  sprintf("'%s'", x)
}


dde_abind <- function(a, b) {
  na <- dim(a)[3]
  nb <- dim(b)[3]
  nab <- dim(a)[1:2]
  ret <- array(NA_real_, c(nab, na + nb))
  ret[, , seq_len(na)] <- a
  ret[, , seq_len(nb) + na] <- b
  ret
}


split_df_rows <- function(x) {
  unname(split(x, seq_len(nrow(x))))
}
