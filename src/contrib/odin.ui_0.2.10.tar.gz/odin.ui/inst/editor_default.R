deriv(x) <- x * r
initial(x) <- 1
r <- user(1)
