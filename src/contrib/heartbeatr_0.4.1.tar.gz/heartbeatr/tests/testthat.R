library(testthat)
library(heartbeatr)

test_check("heartbeatr")
