library(testthat)
library(dust)

test_check("dust")
