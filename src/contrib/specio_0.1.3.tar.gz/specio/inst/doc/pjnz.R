## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
unzip(system.file("testdata", "Botswana2018.PJNZ", package = "specio"), 
      list = TRUE)

## ---- echo = FALSE-------------------------------------------------------
data <- specio:::get_dp_data(
  system.file("testdata", "Botswana2018.PJNZ", package = "specio")
)
str(data[1:10])

## ---- echo = FALSE-------------------------------------------------------
tag <- which(data[, "Tag"] == "<CD4ThreshHoldAdults MV>")
data[seq.int(tag, tag + 3), 1:7]

