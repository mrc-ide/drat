## 0.1.3

Fix windows BOM bug using manual column name fix

## 0.1.2

Fix bug reading Spectrum 2019 files

## 0.1.1

Fix bug on windows where read.csv including byte order mark in column names of DP file

## 0.1.0

Add extract_population and extract_hiv_population methods
