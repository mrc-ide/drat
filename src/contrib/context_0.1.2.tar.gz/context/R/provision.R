##' Provision a context
##' @title Provision a context
##'
##' @param ctx A context object.  We'll look in here for packages to install.
##'
##' @param platform Platform to create the library for
##'
##' @param version Version of R to create the library for
##'
##' @param quiet Be quiet when installing source packages
##'
##' @param allow_missing Allow packages requiring compilation to be
##'   skipped over?  If \code{TRUE} you'll need to sort these out
##'   yourself.
##'
##' @param installed_action Action if packages are installed
##'
##' @param additional_libraries Character vector of additional
##'   libraries to pass through to \code{provisionr}.  Packages here
##'   will be counted when determining what to install and upgrade
##'   (based on \code{installed_action}).
##'
##' @param refresh_drat Force-refresh any local packages that are
##'   listed in the \code{package_sources} argument to
##'   \code{context_save}
##'
##' @export
provision_context <- function(ctx, platform = NULL, version = NULL,
                              quiet = FALSE, allow_missing = FALSE,
                              installed_action = "skip",
                              additional_libraries = NULL,
                              refresh_drat = FALSE) {
  loadNamespace("provisionr")
  path_root <- ctx$root$path
  ## This can be used to put onto the shared drive (in didehpc/drat)
  ## so that installation can be further sped up.
  url_context <- getOption("context.drat", "https://dide-tools.github.io/drat/")
  if (is.null(ctx$package_sources)) {
    src <- provisionr::package_sources(repos = url_context)
  } else {
    src <- ctx$package_sources$clone()
    src$repos <- c(url_context, src$repos)
  }

  if (!is.null(src) && is.null(src$local_drat)) {
    ## No need to clone here because we're guaranteed a freshly
    ## created/cloned package sources by here.
    src$local_drat <- path_drat(path_root)
  }

  packages <- c("context", ctx$packages$attached, ctx$packages$loaded)

  path_lib <- c(path_library(path_root, platform, version),
                additional_libraries)

  context_log("provision", sprintf("library at %s", path_lib[[1L]]))
  for (p in path_lib[-1]) {
    context_log("provision", sprintf("additional library at %s", p))
  }
  res <- provisionr::provision_library(
    packages, path_lib, platform = platform, version = version, src = src,
    check_dependencies = TRUE, installed_action = installed_action,
    allow_missing = allow_missing, quiet = quiet, refresh_drat = refresh_drat)

  invisible(res)
}
