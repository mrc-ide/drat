library(testthat)
library(cinterpolate)

test_check("cinterpolate")
