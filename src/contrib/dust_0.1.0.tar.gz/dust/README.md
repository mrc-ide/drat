# dust <img src='man/figures/logo.png' align="right" height="139" />

<!-- badges: start -->
[![Project Status: WIP – Initial development is in progress, but there has not yet been a stable, usable release suitable for the public.](https://www.repostatus.org/badges/latest/wip.svg)](https://www.repostatus.org/#wip)
[![Build Status](https://travis-ci.com/mrc-ide/dust.svg?branch=master)](https://travis-ci.com/mrc-ide/dust)
[![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/mrc-ide/dust?branch=master&svg=true)](https://ci.appveyor.com/project/mrc-ide/dust)
[![CodeFactor](https://www.codefactor.io/repository/github/mrc-ide/dust/badge)](https://www.codefactor.io/repository/github/mrc-ide/dust)
[![codecov.io](https://codecov.io/github/mrc-ide/dust/coverage.svg?branch=master)](https://codecov.io/github/mrc-ide/dust?branch=master)
<!-- badges: end -->

Fast and simple iteration of stochastic models. Designed to work as a component of a particle filter.

## License

MIT © Imperial College of Science, Technology and Medicine
