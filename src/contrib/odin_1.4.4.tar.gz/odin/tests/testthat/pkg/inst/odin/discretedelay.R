initial(y) <- 1
update(y) <- y + yprev
yprev <- delay(y, 1)
