initial(x[]) <- 0
update(x[]) <- rnorm(x[i], 1)
dim(x) <- 3
