## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  error = FALSE)

## ---- results = "asis", echo = FALSE-------------------------------------
path <- system.file("examples/simple.json", package = "traduire",
                    mustWork = TRUE)
writeLines(c("```json",  readLines(path), "```"))

## ------------------------------------------------------------------------
translator <- traduire::i18n(path, "en")
translator

## ------------------------------------------------------------------------
translator$t("hello")

## ------------------------------------------------------------------------
translator$t("hello", language = "fr")

## ------------------------------------------------------------------------
translator$t("pluralex1", count = 1, language = "en")
translator$t("pluralex1", count = 2, language = "en")

## ------------------------------------------------------------------------
translator$t("interpolate", list(what = "i18next", how = "easy"),
             language = "en")
translator$t("interpolate", list(what = "i18next", how = "facile"),
             language = "fr")

