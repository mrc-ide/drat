#include <cpp11.hpp>

[[cpp11::register]]
cpp11::sexp dust_gpu_info();
