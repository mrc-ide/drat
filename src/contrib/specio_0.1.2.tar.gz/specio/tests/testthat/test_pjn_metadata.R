context("pjn_metadata")

test_that("projection metadata can be read from PJN file for Botswana 2018", {
  pjn_data <- get_pjn_metadata(pjn_botswana_2018)

  expect_equal(pjn_data$country, "Botswana")
  expect_equal(pjn_data$iso3, 72)
  expect_null(pjn_data$region)
  expect_equal(pjn_data$spectrum_version, "5.63")
  expect_equal(pjn_data$projection_name, "Botswana_ 2018 updated ART")
})

test_that("projection metadata can be read from PJN file for Mozambique 2018", {
  pjn_data <- get_pjn_metadata(pjn_mozambique_2018)

  expect_equal(pjn_data$country, "Mozambique")
  expect_equal(pjn_data$iso3, 508)
  expect_equal(pjn_data$region, "SOUTH_Maputo Cidade")
  expect_equal(pjn_data$spectrum_version, "5.63")
  expect_equal(pjn_data$projection_name,
               "11_MZ_Maputo Cidade_v5_63_updated census_22_01_2018")
})
