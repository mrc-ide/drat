library(testthat)
library(drat.builder)

test_check("drat.builder")
