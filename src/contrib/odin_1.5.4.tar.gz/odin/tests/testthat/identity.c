double identity(double x) {
  return x;
}
