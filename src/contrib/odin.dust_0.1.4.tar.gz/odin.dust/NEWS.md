# odin.dust 0.1.4

* Add support for `config(include) <- file.cpp` for including custom C++ code to extend the library support (#39)

# odin.dust 0.1.0

* Add support for odin-like `coef()`, which returns information about `user` parameters (#32)
