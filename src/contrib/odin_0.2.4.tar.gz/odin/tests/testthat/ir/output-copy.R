deriv(y[]) <- y[i] * r[i]
initial(y[]) <- i
dim(y) <- 3
dim(r) <- 3
r[] <- user()
output(yr[]) <- y[i] / i
dim(yr) <- 3
output(r[]) <- TRUE
