deriv(y) <- 2
initial(y) <- 1
output(z) <- t
