# 1.0.0

* Initial public release
* Validate the derivatives are finite (non-NA, non-infinite) before the first step, avoiding cryptic errors [#13](https://github.com/mrc-ide/dde/issues/13)

# 0.0.6

* Replication interface for `difeq` as `difeq_replicate` [#10](https://github.com/mrc-ide/dde/issues/10)
