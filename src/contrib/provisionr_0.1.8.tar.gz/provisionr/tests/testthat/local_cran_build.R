#!/usr/bin/env Rscript
devtools::load_all()
source("helper-provisionr.R")
make_local_cran()
