# Test certificates

These certificates are used to test TLS authentication in vault. Do not reuse them for any other purposes.  They are generated as-needed by the `generate.sh` command.  This is the same approach for testing as used by [hvac](https://github.com/ianunruh/hvac), and this implementation follows theirs verbatim.
