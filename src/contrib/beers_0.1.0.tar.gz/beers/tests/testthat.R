library(testthat)
library(beers)

test_check("beers")
