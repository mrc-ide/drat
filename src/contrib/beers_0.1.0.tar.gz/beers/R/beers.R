#' beers: A package for computing Beers ordinary and modified interpolation
#'
#' @docType package
#' @name beers
NULL
