a <- 10
f <- function(x) {
  a + x
}
