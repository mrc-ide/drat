deriv(x) <- x
initial(x) <- 1
