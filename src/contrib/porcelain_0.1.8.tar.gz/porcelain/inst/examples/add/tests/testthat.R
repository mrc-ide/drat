library(testthat)
library(add)

test_check("add")
