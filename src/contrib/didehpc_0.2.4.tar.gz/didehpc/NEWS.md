# didehpc 0.2.4

* Fixes for different slashes for FQDN fix([#62](https://github.com/mrc-ide/didehpc/pull/62)) by `@weshinsley`

# didehpc 0.2.3

* Workaround a server share issue by using fully-qualified domain address (.dide.ic.ac.uk) for the home and temp shares. ([#61](https://github.com/mrc-ide/didehpc/pull/61)) by `@weshinsley`

# didehpc 0.2.2

* Support adding a Java Runtime to the path. ([#58](https://github.com/mrc-ide/didehpc/pull/59)) by `@weshinsley`

# didehpc 0.2.1

* Fixed rrq support, which had broken with changes I made to rrq

# didehpc 0.2.0

* Support for R 3.4.x and 3.5.x ([#54](https://github.com/mrc-ide/didehpc/issues/54))
* Better detection of windows mounts ([#52](https://github.com/mrc-ide/didehpc/pull/52)) by `@weshinsley`
* Documentation improvements ([#47](https://github.com/mrc-ide/didehpc/pull/47)) by `@weshinsley`

# didehpc 0.1.6

* Fix mount-point detection failure with wmic occurring on some Windows machines.

# didehpc 0.1.5

* Check what resources a user has on login ([#50](https://github.com/mrc-ide/didehpc/issues/50))

# didehpc 0.1.4

* Support for machines set up to use `qdrive` ([#48](https://github.com/mrc-ide/didehpc/issues/48))
