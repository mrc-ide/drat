function squarepulse(t, t0, t1) {
    return t >= t0 && t < t1;
}
