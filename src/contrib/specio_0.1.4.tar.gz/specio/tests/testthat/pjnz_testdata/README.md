Note Botswana2019 file is the Botswana2017 data saved using the 2019 version of Spectrum. It is used for testing reading from updated data structure for HH survey data.

When publicly available data for 2019 is available we should replace this with actual 2019 data.

The files here are PJNZ files which have had large files removed from the archive. The removed files are specific to the dataset removed files include .bm2, .UAC, and sometimes .DPUAD_AUA, .ep5.bak and .SPU. See mrc-ide/eppasm/data-raw/test-pjnz.R for details.
