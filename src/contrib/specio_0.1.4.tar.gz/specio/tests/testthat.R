library(testthat)
library(specio)

test_check("specio")
