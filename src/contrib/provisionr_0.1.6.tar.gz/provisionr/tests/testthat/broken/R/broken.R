invalid r code
