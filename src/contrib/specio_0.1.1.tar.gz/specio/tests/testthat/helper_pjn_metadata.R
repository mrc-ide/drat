pjn_botswana_2018 <- utils::read.csv("pjn_testdata/Botswana_2018_updated_ART.PJN", as.is = TRUE)
pjn_mozambique_2018 <- utils::read.csv("pjn_testdata/Mozambique_Maputo_Cidade2018.PJN", as.is = TRUE)
