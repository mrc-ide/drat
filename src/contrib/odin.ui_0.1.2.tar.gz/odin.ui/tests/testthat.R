library(testthat)
library(odin.ui)

test_check("odin.ui")
