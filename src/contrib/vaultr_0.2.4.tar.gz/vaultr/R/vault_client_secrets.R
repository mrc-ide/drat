##' Interact with vault's secret backends.
##'
##' @template vault_client_secrets
##'
##' @title Vault Secret Configuration
##' @name vault_client_secrets
NULL


R6_vault_client_secrets <- R6::R6Class(
  "vault_client_secrets",

  private = list(api_client = NULL),

  public = list(
    ## it would be really nice to directly support mounting this elsewhere
    transit = NULL,

    initialize = function(api_client) {
      private$api_client <- api_client
      self$transit <- R6_vault_client_transit$new(api_client, "transit")
    },

    format = function(brief = FALSE) {
      vault_client_format(self, brief, "secrets",
                          "Interact with secret engines")
    },

    disable = function(path) {
      if (!is_absolute_path(path)) {
        path <- paste0("/", path)
      }
      private$api_client$DELETE(paste0("/sys/mounts", path))
      invisible(NULL)
    },

    enable = function(type, path = type, description = NULL, version = NULL) {
      ## TODO: there are many additional options here that are not
      ## currently supported and which would come through the "config"
      ## argument.
      assert_scalar_character(type)
      assert_scalar_character(path)
      assert_scalar_character_or_null(description)

      if (!is_absolute_path(path)) {
        path <- paste0("/", path)
      }
      data <- list(type = type,
                   description = description)
      if (!is.null(version)) {
        data$options <- list(version = as.character(version))
      }
      private$api_client$POST(paste0("/sys/mounts", path), body = data)
      invisible(path)
    },

    list = function(detailed = FALSE) {
      if (detailed) {
        stop("Detailed secret information not supported")
      }
      dat <- private$api_client$GET("/sys/mounts")
      cols <- c("type", "accessor", "description")
      ret <- lapply(cols, function(v)
        vapply(dat$data, "[[", "", v, USE.NAMES = FALSE))
      names(ret) <- cols
      as.data.frame(c(list(path = names(dat$data)), ret),
                    stringsAsFactors = FALSE, check.names = FALSE)
    },

    move = function(from, to) {
      assert_scalar_character(from)
      assert_scalar_character(to)
      body <- list(from = from, to = to)
      private$api_client$POST("/sys/remount", body = body)
      invisible(NULL)
    }
  ))
