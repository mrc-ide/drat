# 0.0.6

* Replication interface for `difeq` as `difeq_replicate` [#10](https://github.com/richfitz/dde/issues/10)
