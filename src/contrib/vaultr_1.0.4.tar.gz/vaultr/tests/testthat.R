library(testthat)
library(vaultr)

test_check("vaultr")
