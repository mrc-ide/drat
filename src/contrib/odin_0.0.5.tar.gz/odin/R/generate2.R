## Almost every function in here generates exactly one function, except:
##
## * odin_generate2_struct(); generates one struct
## * odin_generate2_vars() and odin_generate2_unpack(); support
##   functions used in odin_generate2_deriv and odin_generate2_output
##   (factored out because output and deriv have similar structure).
##
## All of these functions take 'obj' as the first argument; this is
## the result of running odin_generate1().  None of these functions
## modify 'obj'.
##
## Every function that has any other argument has 'output = FALSE' as
## its only other argument; in this case they're unpacking/working
## with output rather than varaibles, as there is quite a bit of
## overlap there.
odin_generate2_struct <- function(obj) {
  types <- obj$types
  ret <- collector()
  ret$add("// Collect together all the parameters and transient memory")
  ret$add("// required to run the model in a struct.")
  ret$add("typedef struct %s {", obj$type_pars)
  ptr <- types$array | types$type %in% SPECIAL_DATA_TYPES
  ret$add("  %s %s%s;", types$type, ifelse(ptr, "*", ""), types$name)
  ret$add("} %s;", obj$type_pars)
  ret$get()
}

odin_generate2_support_decls <- function(obj) {
  ret <- collector()
  ret$add("%s* %s_get_pointer(SEXP %s_ptr, int closed_error);",
          obj$type_pars, obj$info$base, obj$info$base)
  if (obj$info$has_user) {
    ret$add("SEXP %s_set_user(%s *%s, SEXP %s);",
            obj$info$base, obj$type_pars, obj$name_pars, USER)
  }
  ret$get()
}

odin_generate2_support_defns <- function(obj) {
  ret <- collector()
  ret$add("%s* %s_get_pointer(SEXP %s_ptr, int closed_error) {",
          obj$type_pars, obj$info$base, obj$info$base)
  ret$add("  %s *%s = NULL;", obj$type_pars, obj$name_pars)
  ret$add("  if (TYPEOF(%s_ptr) != EXTPTRSXP) {", obj$info$base)
  ret$add('    Rf_error("Expected an external pointer");')
  ret$add("  }")
  ret$add("  %s = (%s*) R_ExternalPtrAddr(%s_ptr);",
          obj$name_pars, obj$type_pars, obj$info$base)
  ret$add("  if (!%s && closed_error) {", obj$name_pars)
  ret$add('    Rf_error("Pointer has been invalidated");')
  ret$add("  }")
  ret$add("  return %s;", obj$name_pars)
  ret$add("}")
  ret$get()
}

cinterpolate_library_fns <- function() {
  read <- function(x) {
    paste(readLines(x), collapse = "\n")
  }
  path <- system.file("include/cinterpolate", package = "cinterpolate",
                      mustWork = TRUE)
  list(declarations = read(file.path(path, "cinterpolate.h")),
       definitions = read(file.path(path, "cinterpolate.c")))
}

odin_generate2_library_fns <- function(obj) {
  dat <- read_user_c(system.file("library.c", package = "odin"))
  if (obj$safe) {
    dat <- join_library(list(dat, odin_generate2_library_safe()))
  }

  fns <- obj$library_fns$get()
  if (any(grepl("^get_user_", fns))) {
    fns <- c(fns, "get_list_element")
  }
  if (obj$info$has_interpolate) {
    fns <- c(fns, "odin_interpolate_check")
    lib_interpolate <- cinterpolate_library_fns()
  } else {
    lib_interpolate <- NULL
  }

  fns <- unique(fns)
  fns_sum <- intersect(FUNCTIONS_SUM, fns)
  fns <- setdiff(fns, fns_sum)

  err <- setdiff(fns, names(dat$declarations))
  if (length(err) > 0L) {
    stop("library function not found [odin bug]: ", pastec(err)) # nocov
  }
  lib <- list(declarations = dat$declarations[fns],
              definitions = dat$definitions[fns])
  lib_sum <- odin_generate2_library_sum(fns_sum)

  join_library(list(lib, lib_sum, lib_interpolate, obj$custom))
}

odin_generate2_library_safe <- function() {
  p <- function(...) {
    paste0(c(...), "\n", collapse = "")
  }
  lines_get <- p(
    "double odin_array_at%d(double *x, size_t at,",
    "                      %s, %s,",
    "                      const char * variable, const char * expr_str) {",
    "  int i[%d] = {%s};",
    "  size_t len[%d] = {%s};",
    "  odin_array_check(%d, i, len, variable, expr_str, false);",
    "  return x[at];",
    "}")
  lines_set <- p(
    "void odin_array_at_set%d(double *x, size_t at, double value,",
    "                        %s, %s,",
    "                        const char * variable, const char * expr_str) {",
    "  int i[%d] = {%s};",
    "  size_t len[%d] = {%s};",
    "  odin_array_check(%d, i, len, variable, expr_str, true);",
    "  x[at] = value;",
    "}")

  f <- function(n) {
    i <- paste0("i", seq_len(n))
    len <- paste0("len", seq_len(n))
    decl_i <- paste("int", i, collapse = ", ")
    decl_len <- paste("size_t", len, collapse = ", ")
    use_i <- paste(i, collapse = ", ")
    use_len <- paste(len, collapse = ", ")
    ret <- c(sprintf(lines_get, n, decl_i, decl_len, n, use_i, n, use_len, n),
             sprintf(lines_set, n, decl_i, decl_len, n, use_i, n, use_len, n))
    names(ret) <- sprintf(c("odin_array_at%d", "odin_array_at_set%d"), n)
    ret
  }

  defns <- unlist(lapply(2:length(INDEX), f), FALSE, use.names = TRUE)
  decls <- sub("\\s*\\{.*", ";", defns)
  list(declarations = decls, definitions = defns)
}

odin_generate2_library_sum <- function(fns) {
  nd <- setNames(match(fns, FUNCTIONS_SUM), fns)
  join_library(lapply(nd, odin_generate2_sum))
}

## NOTE: all sums are over _inclusive_ ranges, rather than the more
## typically C _exclusive_ range, for consistency with how these
## functions will be used.  In particular while we take care of the
## base1 to base0 mapping of most expressions, things that come in as
## index varibles (i, j, k) do not get subtracted as they are dealt
## with elsewhere.  So we can't just knock one off the "from" index
## and have things work because then a sum over an index (e.g.,
## sum(foo[i, ])) won't work because the limits would translate as
## {(i,i), (0, dim2)}.  Instead, using an inclusive range we can apply
## the transformation consistently and get {(i,i), (0, dim2-1)} which
## looks weird but should work everywhere.
odin_generate2_sum <- function(nd) {
  i <- seq_len(nd)
  dim <- vcapply(seq_len(nd), function(x)
    array_dim_name("x", paste(seq_len(x - 1), collapse = "")))

  args_idx <- sprintf("int from_%s, int to_%s", INDEX[i], INDEX[i])

  decl <- sprintf("double odin_sum%d(double *x, %s)",
                   nd, pastec(c(args_idx, sprintf("int %s", dim[-1L]))))

  ret <- collector()

  ret$add("%s {", decl)
  ret$add("  double tot = 0.0;")
  idt <- rev(seq(2, by = 2, length.out = nd))
  counter <- vcapply(INDEX[i], strrep, n = 2)

  for (j in rev(i)) {
    idx <- INDEX[j]
    ret$add(indent(sprintf("for (int %s = from_%s; %s <= to_%s; ++%s) {",
                           idx, idx, idx, idx, idx), idt[[j]]))
    if (j > 1) {
      start <- (if (j == nd) sprintf("%s * %s", INDEX[j], dim[j])
                else sprintf("%s * %s + %s", INDEX[j], dim[j], counter[[j+1]]))
      ret$add(indent(sprintf("int %s = %s;", counter[[j]], start),
                     idt[[j]] + 2))
    } else {
      idx <- (if (nd == 1L) INDEX[[1L]]
              else sprintf("%s + %s", INDEX[[1L]], counter[[2L]]))
      ret$add(indent(sprintf("tot += x[%s];", idx), idt[[j]] + 2L))

    }
  }

  ## Close all braces:
  ret$add(vcapply(idt, indent, x = "}"))

  ret$add("  return tot;")
  ret$add("}")

  list(declarations = sprintf("%s;", decl),
       definitions = paste(ret$get(), collapse = "\n"))
}

## TODO: For now, odin_interpolate_support is elsewhere.

## TODO: For now, odin_header(), odin_includes() elsewhere

odin_generate2_create <- function(obj) {
  ret <- collector()
  ret$add("// Create the pointer; this will establish the struct, allocate")
  ret$add("// memory for things that are constant size, and initialize")
  ret$add("// constant variables")
  ## NOTE: finalize definition in odin_generate2_finalize()
  ret$add("static void %s_finalize(SEXP %s_ptr);", obj$info$base, obj$info$base)

  ## NOTE: This is somewhat duplicated in odin_generate_r_initialize
  args <- c(character(),
            if (obj$info$has_user) USER,
            if (!obj$info$discrete) "odin_use_dde")

  ret$add("SEXP %s_create(%s) {", obj$info$base,
          pastec(sprintf("SEXP %s", args)))
  ret$add("  %s *%s = (%s*) Calloc(1, %s);",
          obj$type_pars, obj$name_pars, obj$type_pars, obj$type_pars)
  constant <- obj$constant$get()
  if (length(constant) > 0L) {
    ret$add(indent(constant, 2))
  }
  ret$add(
    "  SEXP %s_ptr = PROTECT(R_MakeExternalPtr(%s, R_NilValue, R_NilValue));",
    obj$info$base, obj$name_pars)
  ret$add("  R_RegisterCFinalizer(%s_ptr, %s_finalize);",
          obj$info$base, obj$info$base)
  ## NOTE: set user variables *after* creating the pointer and
  ## finaliser to avoid any memory leak in the case of set_user
  ## failing (as it throws on failure so the Free()'s would never
  ## happen).
  if (obj$info$has_user) {
    ret$add("  %s_set_user(%s, %s);", obj$info$base, obj$name_pars, USER)
  }
  if (!obj$info$discrete) {
    ret$add("  %s = INTEGER(odin_use_dde)[0];", obj$rewrite("odin_use_dde"))
  }
  ret$add("  UNPROTECT(1);")
  ret$add("  return %s_ptr;", obj$info$base)
  ret$add("}")
  ret$get()
}

odin_generate2_user <- function(obj) {
  if (!obj$info$has_user) {
    return(NULL)
  }
  ret <- collector()
  ret$add("// Set user-supplied parameter values.")
  ret$add("SEXP %s_set_user(%s *%s, SEXP %s) {",
          obj$info$base, obj$type_pars, obj$name_pars, USER)
  user <- obj$user$get()
  if (length(user) > 0L) {
    ret$add(indent(user, 2))
  }
  ret$add("  return R_NilValue;")
  ret$add("}")
  ret$add("// Wrapper around this for use from R.")
  ret$add("SEXP r_%s_set_user(SEXP %s_ptr, SEXP %s) {",
          obj$info$base, obj$info$base, USER)
  ret$add("  %s *%s = %s_get_pointer(%s_ptr, 1);",
          obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)
  ret$add("  %s_set_user(%s, %s);", obj$info$base, obj$name_pars, USER)
  ret$add("  return R_NilValue;")
  ret$add("}")
  ret$get()
}

odin_generate2_finalize <- function(obj) {
  ret <- collector()
  ret$add("// Arrange to free all memory we have allocated")
  ret$add("// This is called by R automatically when the pointer is")
  ret$add("// garbage collected (i.e., when all objects holding the pointer")
  ret$add("// go out of scope")
  ## NOTE: declaration for this is made in odin_generate2_create()
  ret$add("void %s_finalize(SEXP %s_ptr) {", obj$info$base, obj$info$base)
  ret$add("  %s *%s = %s_get_pointer(%s_ptr, 0);",
          obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)
  ret$add("  if (%s_ptr) {", obj$info$base)
  free <- obj$free$get()
  if (length(free) > 0L) {
    ret$add(indent(free, 4))
  }
  ret$add("    Free(%s);", obj$name_pars)
  ret$add("    R_ClearExternalPtr(%s_ptr);", obj$info$base)
  ret$add("  }")
  ret$add("}")
  ret$get()
}

odin_generate2_initial <- function(obj) {
  discrete <- obj$info$discrete
  time_name <- if (discrete) STEP else TIME
  time_type <- if (discrete) "int" else "double"
  use_rng <- discrete && obj$info$has_stochastic
  ret <- collector()
  ret$add("SEXP %s_initialise(SEXP %s_ptr, SEXP %s_ptr) {",
          obj$info$base, obj$info$base, time_name)
  ret$add("  %s *%s = %s_get_pointer(%s_ptr, 1);",
          obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)
  if (use_rng) {
    ret$add("  GetRNGstate();")
  }

  initial <- obj$initial$get()

  if (obj$info$has_delay || length(initial) > 0L ||
      obj$info$initial_stage == STAGE_TIME) {
    if (obj$info$has_delay || time_name %in% obj$info$eqs_used$initial) {
      time_access <- if (discrete) "INTEGER" else "REAL"
      ret$add("  const %s %s = %s(%s_ptr)[0];",
              time_type, time_name, time_access, time_name)
    }
    if (obj$info$has_delay) {
      ret$add("  %s = %s;", obj$rewrite(initial_name(time_name)), time_name)
    }

    ## Dependencies of any initial expressions, filtered by time dependency:
    time <- obj$time$get()
    time <- time[names(time) %in% obj$info$eqs_used$initial]

    ## Then, we determine which *variables* are used here.  This
    ## should be possible to work out earlier, but I'm just doing it
    ## here for now (TODO).  The better way of doing this would be to
    ## rewrite the expressions for all dependencies of initial
    ## conditions to swap initial(x) -> x or x -> initial(x).
    if (length(time) > 0L) {
      i <- obj$variable_info$order %in% obj$info$eqs_used$initial
      if (any(i)) {
        j <- obj$variable_info$is_array[i]
        if (any(j)) {
          va <- obj$variable_info$order[i][j]
          ret$add("  double *%s = %s;",
                  va, vcapply(initial_name(va), obj$rewrite))
        }
        if (any(!j)) {
          for (v in obj$variable_info$order[i][!j]) {
            iv <- initial_name(v)
            ## NOTE: The '0' here is used for user variables, as they
            ## don't appear in the 'time' list
            at <- max(c(0L, which(names(time) == iv)))
            tmp <- setNames(sprintf("double %s = %s;", v, obj$rewrite(iv)), iv)
            time <- append(time, tmp, at)
          }
        }
      }
      ret$add(indent(time, 2))
    }

    ## And time-sensitive initial expressions
    if (length(initial) > 0L) {
      ## NOTE: This _used_ to be used but is not with this set of
      ## changes.  I'm not certain I can prove it is never used
      ## though.
      stop("This should not longer be used [odin bug]") # nocov
      ## ret$add(indent(initial, 2))
    }
  }

  vars_info <- obj$variable_info
  ## It's possible this bit should be factored out into a separate function?
  ret$add("  SEXP %s = PROTECT(allocVector(REALSXP, %s));",
          STATE, obj$rewrite(obj$variable_info$total_use))
  copy <- character(vars_info$n)
  i <- vars_info$is_array
  nm_initial <- vcapply(initial_name(vars_info$order), obj$rewrite)
  offset <- vcapply(vars_info$offset_use, obj$rewrite)
  copy[i] <- sprintf("  memcpy(REAL(%s) + %s, %s, %s * sizeof(double));",
                     STATE, offset[i], nm_initial[i],
                     vcapply(vars_info$len[i], obj$rewrite))
  copy[!i] <- sprintf("  REAL(%s)[%s] = %s;",
                      STATE, offset[!i], nm_initial[!i])
  ret$add(copy)
  if (obj$info$has_output) {
    ret$add('  setAttrib(%s, install("%s_len"), ScalarInteger(%s));',
            STATE, OUTPUT, obj$rewrite(obj$output_info$total_use))
  }
  if (use_rng) {
    ret$add("  PutRNGstate();")
  }

  ret$add("  UNPROTECT(1);")
  ret$add("  return %s;", STATE)
  ret$add("}")
  ret$get()
}

odin_generate2_set_initial <- function(obj) {
  if (obj$info$discrete) {
    time_name <- STEP
    time_type <- "int"
    time_access <- "INTEGER"
  } else {
    time_name <- TIME
    time_type <- "double"
    time_access <- "REAL"
  }
  ret <- collector()
  ret$add("SEXP %s_set_initial(SEXP %s_ptr, SEXP %s_ptr, SEXP %s_ptr) {",
          obj$info$base, obj$info$base, time_name, STATE)
  if (obj$info$has_delay) {
    ret$add("  %s *%s = %s_get_pointer(%s_ptr, 1);",
            obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)

    vars_info <- obj$variable_info

    ret$add("  if (length(%s_ptr) != %s) {",
            obj$info$base, obj$rewrite(vars_info$total_use))
    ret$add('    Rf_error("Incorrect length initial conditions");')
    ret$add("  }")
    ret$add("  double * %s = REAL(%s_ptr);", STATE, STATE)

    ret$add("  const %s %s = %s(%s_ptr)[0];",
            time_type, time_name, time_access, time_name)
    ret$add("  %s = %s;", obj$rewrite(initial_name(time_name)), time_name)

    ## NOTE: This is the inverse of generate2_initial() above
    nm_initial <- vcapply(initial_name(vars_info$order), obj$rewrite)
    i <- vars_info$is_array
    copy <- character(vars_info$n)
    offset <- vcapply(vars_info$offset_use, obj$rewrite)

    copy[i] <- sprintf("  memcpy(%s, %s + %s, %s * sizeof(double));",
                       nm_initial[i], STATE, offset[i],
                       vcapply(vars_info$len[i], obj$rewrite))
    copy[!i] <- sprintf("  %s = %s[%s];",
                        nm_initial[!i], STATE, offset[!i])
    ret$add(copy)
  }
  ret$add("  return R_NilValue;")
  ret$add("}")
  ret$get()
}

## OK, this one is slightly complicated because there are *three*
## forms of the derivative function.  The base one (that this does)
## returns void and takes a pointer.
odin_generate2_deriv <- function(obj) {
  ret <- collector()
  discrete <- obj$info$discrete

  core_name <- if (discrete) "update" else "deriv"
  time_name <- if (discrete) STEP else TIME
  time_type <- if (discrete) "size_t" else "double"
  ret_name <- if (discrete) STATE_NEXT else DSTATEDT

  info <- obj$variable_info

  ret$add(
    "void %s_%s(%s *%s, %s %s, double *%s, double *%s, double *%s) {",
    obj$info$base, core_name, obj$type_pars, obj$name_pars,
    time_type, time_name, STATE, ret_name, OUTPUT)
  ret$add(indent(odin_generate2_vars(obj), 2))
  ret$add(indent(odin_generate2_unpack(obj, "variables"), 2))
  ret$add(indent(odin_generate2_unpack(obj, "delays"), 2))
  if (discrete && obj$info$has_delay) {
    ret$add("  double * %s_head = (double*)%s->head;", RING, obj$rewrite(RING))
  }

  time <- obj$time$get()
  time_deriv <- time[names(time) %in% obj$info$eqs_used[[core_name]]]
  if (length(time_deriv) > 0L) {
    ret$add(indent(time_deriv, 2))
  }

  ## The conditional here means that we'll be able to be compatible
  ## with both dde and deSolve, as they totally differ in how output
  ## variables are computed.  We pass a NULL through for output for
  ## dde so this will skip pretty happily.
  if (obj$info$has_output) {
    keep <- setdiff(obj$info$eqs_used$output, obj$info$eqs_used[[core_name]])
    time_output <- time[names(time) %in% keep]
    ret$add("  if (%s != NULL) {", OUTPUT)
    ret$add(indent(odin_generate2_unpack(obj, "output"), 4))
    ret$add(indent(time_output, 4))
    ret$add("  }")
  }

  if (discrete && obj$info$has_delay) {
    ret$add("  ring_buffer_head_advance(%s);", obj$rewrite(RING))
  }

  ret$add("}")
  ret$get()
}

odin_generate2_update_dde <- function(obj) {
  ret <- collector()
  ret$add(
    "void %s_update_dde(size_t n, size_t %s, double *%s, double *%s,",
    obj$info$base, STEP, STATE, STATE_NEXT)
  ret$add(
    "               size_t n_out, double *%s, void *%s) {",
    OUTPUT, obj$name_pars)
  ret$add("  %s_update((%s*)%s, %s, %s, %s, %s);",
          obj$info$base, obj$type_pars, obj$name_pars,
          STEP, STATE, STATE_NEXT, OUTPUT)
  ret$add("}")
  ret$get()
}

odin_generate2_deriv_r <- function(obj) {
  ret <- collector()

  discrete <- obj$info$discrete
  core_name <- if (discrete) "update" else "deriv"
  time_name <- if (discrete) STEP else TIME
  time_type <- if (discrete) "size_t" else "double"
  time_access <- if (discrete) "INTEGER" else "REAL"
  ret_name <- if (discrete) STATE_NEXT else DSTATEDT

  ret$add("SEXP %s_%s_r(SEXP %s_ptr, SEXP %s, SEXP %s) {",
          obj$info$base, core_name, obj$info$base, time_name, STATE)
  ret$add("  SEXP %s = PROTECT(allocVector(REALSXP, LENGTH(%s)));",
          ret_name, STATE)
  ret$add("  %s *%s = %s_get_pointer(%s_ptr, 1);",
          obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)

  if (obj$info$has_output) {
    ret$add("  SEXP %s_ptr = PROTECT(allocVector(REALSXP, %s));",
            OUTPUT, obj$rewrite(obj$output_info$total_use))
    ret$add('  setAttrib(%s, install("%s"), %s_ptr);',
            ret_name, OUTPUT, OUTPUT)
    ret$add("  double *%s = REAL(%s_ptr);", OUTPUT, OUTPUT)
    np <- 2L
  } else {
    ret$add("  double *%s = NULL;", OUTPUT)
    np <- 1L
  }

  ret$add("  %s_%s(%s, %s(%s)[0], REAL(%s), REAL(%s), %s);",
          obj$info$base, core_name, obj$name_pars, time_access, time_name,
          STATE, ret_name, OUTPUT)
  ret$add("  UNPROTECT(%d);", np)
  ret$add("  return %s;", ret_name)
  ret$add("}")
  ret$get()
}

odin_generate2_contents <- function(obj) {
  types <- obj$types
  len <- nrow(types)

  rtype <- c(int = "INTSXP", double = "REALSXP")
  raccess <- c(int = "INTEGER", double = "REAL")

  ret <- collector()
  ret$add("// Translate all elements in the struct back to R")
  ret$add("// This will mostly be useful for debugging.")
  ret$add("SEXP %s_contents(SEXP %s_ptr) {", obj$info$base, obj$info$base)
  ret$add("  %s *%s = %s_get_pointer(%s_ptr, 1);",
          obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)
  ret$add("  SEXP %s = PROTECT(allocVector(VECSXP, %d));",
          STATE, len)

  for (i in seq_len(len)) {
    name <- types$name[[i]]
    type <- types$type[[i]]
    array <- types$array[[i]]
    if (type %in% SPECIAL_DATA_TYPES) {
      ## Can't do anything with these.
      next
    }
    if (array > 0L) {
      name_dim <- array_dim_name(name)
      ret$add("  SET_VECTOR_ELT(%s, %d, allocVector(%s, %s));",
                   STATE, i - 1L, rtype[[type]], obj$rewrite(name_dim))
      ret$add("  memcpy(%s(VECTOR_ELT(%s, %d)), %s, %s * sizeof(%s));",
              raccess[[type]], STATE, i - 1L, obj$rewrite(name),
              obj$rewrite(name_dim), type)
      if (array > 1L) {
        args <- vcapply(seq_len(array), function(j)
          obj$rewrite(array_dim_name(name, j)))
        ret$add("  odin_set_dim(VECTOR_ELT(%s, %d), %d, %s);",
                STATE, i - 1L, array, paste(args, collapse = ", "))
      }
    } else {
      type <- if (type == "int") "Integer" else "Real"
      ret$add("  SET_VECTOR_ELT(%s, %d, Scalar%s(%s));",
              STATE, i - 1L, type, obj$rewrite(name))
    }
  }

  ret$add("  SEXP %s_names = PROTECT(allocVector(STRSXP, %d));",
          STATE, len)
  ret$add('  SET_STRING_ELT(%s_names, %d, mkChar("%s"));',
          STATE, seq_len(len) - 1L, types$name)

  ret$add("  setAttrib(%s, R_NamesSymbol, %s_names);", STATE, STATE)
  ret$add("  UNPROTECT(2);")
  ret$add("  return %s;", STATE)
  ret$add("}")

  ret$get()
}

odin_generate2_order <- function(obj, output = FALSE) {
  if (output && !obj$info$has_output) {
    return(NULL)
  }
  ret <- collector()
  if (output) {
    ret$add("// Report back to R information on output variable ordering")
    ret$add("// Like the variable order above, but for any output vars")
  } else {
    ret$add("// Report back to R information on variable ordering")
    ret$add("// The reported information includes position and length of each")
    ret$add("// variable, from which offset, etc, can be worked out.")
  }
  ret$add("SEXP %s_%s_order(SEXP %s_ptr) {",
          obj$info$base, if (output) "output" else "variable", obj$info$base)

  info <- obj[[if (output) "output_info" else "variable_info"]]
  if (any(info$is_array)) {
    ret$add("  %s *%s = %s_get_pointer(%s_ptr, 1);",
            obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)
    if (max(info$array) > 1L) {
      ret$add("  int *tmp;")
    }
  }
  ret$add("  SEXP %s_len = PROTECT(allocVector(VECSXP, %d));",
          STATE, info$n)
  ret$add("  SEXP %s_names = PROTECT(allocVector(STRSXP, %d));",
          STATE, info$n)

  for (i in seq_len(info$n)) {
    nd <- info$array[[i]]
    if (nd == 0L) {
      ret$add("  SET_VECTOR_ELT(%s_len, %s, R_NilValue);", STATE, i - 1L)
    } else if (nd == 1L) {
      ret$add("  SET_VECTOR_ELT(%s_len, %s, ScalarInteger(%s));",
              STATE, i - 1L, obj$rewrite(info$len[[i]]))
    } else {
      ret$add("  SET_VECTOR_ELT(%s_len, %s, allocVector(INTSXP, %d));",
              STATE, i - 1L, nd)
      ret$add("  tmp = INTEGER(VECTOR_ELT(%s_len, %s));", STATE, i - 1L)
      for (j in seq_len(nd)) {
        ret$add("  tmp[%d] = %s;", j - 1L,
                obj$rewrite(array_dim_name(info$order[[i]], j)))
      }
    }
    ret$add("  SET_STRING_ELT(%s_names, %d, mkChar(\"%s\"));",
            STATE, i - 1L, info$order[[i]])
  }
  ret$add("  setAttrib(%s_len, R_NamesSymbol, %s_names);", STATE, STATE)
  ret$add("  UNPROTECT(2);")
  ret$add("  return %s_len;", STATE)
  ret$add("}")
  ret$get()
}

odin_generate2_output <- function(obj) {
  if (!obj$info$has_output) {
    return(NULL)
  }
  info <- obj$output_info

  ret <- collector()
  ret$add(
    "void %s_output(%s *%s, double %s, double *%s, double *%s) {",
    obj$info$base, obj$type_pars, obj$name_pars, TIME, STATE, OUTPUT)

  ## 1. variables that we need to use
  ret$add(indent(odin_generate2_vars(obj, TRUE), 2))
  ret$add(indent(odin_generate2_unpack(obj, "output"), 2))

  ## 2. dependent calculations
  time <- obj$time$get()
  time <- time[names(time) %in% obj$info$eqs_used$output]
  if (length(time) > 0L) {
    ret$add(indent(time, 2))
  }

  ret$add("}")
  ret$get()
}

odin_generate2_interpolate_t <- function(obj) {
  if (!obj$info$has_interpolate) {
    return(NULL)
  }
  ret <- collector()
  ret$add("// Report back to R information about interpolating functions")
  ret$add("SEXP %s_interpolate_t(SEXP %s_ptr) {", obj$info$base, obj$info$base)

  ret$add("  %s *%s = %s_get_pointer(%s_ptr, 1);",
          obj$type_pars, obj$name_pars, obj$info$base, obj$info$base)
  dat <- unique(obj$interpolate$get())
  dat_type <- vcapply(dat, "[[", "interpolation_type")
  dat_time <- vcapply(dat, "[[", "t")
  tmp <- sort(tapply(dat_type != "constant", dat_time, any), decreasing = TRUE)

  ret$add("  SEXP ret = PROTECT(allocVector(REALSXP, 2));")
  ret$add("  double *r = REAL(ret);")
  v <- names(tmp)[[1L]]
  ret$add("  r[0] = %s[0];", obj$rewrite(v))
  if (tmp[[v]] > 0L) {
    ret$add("  r[1] = %s[%s - 1];",
            obj$rewrite(v), obj$rewrite(array_dim_name(v)))
  } else {
    ret$add("  r[1] = NA_REAL;")
  }
  for (v in names(tmp)[-1]) {
    ret$add("  r[0] = fmax(r[0], %s[0]);", obj$rewrite(v))
    if (tmp[[v]] > 0) {
      ret$add("  r[1] = fmin(r[1], %s[%s - 1]);",
              obj$rewrite(v), obj$rewrite(array_dim_name(v)))
    }
  }
  ret$add("  UNPROTECT(1);")
  ret$add("  return ret;")

  ret$add("}")
  ret$get()
}

odin_generate2_deriv_desolve <- function(obj) {
  ret <- collector()
  ret$add("// deSolve interface")
  ret$add("// Global variable set on initmod, as per deSolve design")
  ret$add("static %s *%s;", obj$type_pars, obj$name_pars)
  ret$add("void %s_initmod_ds(void(* odeparms) (int *, double *)) {",
          obj$info$base)
  ret$add('  DL_FUNC get_deSolve_gparms = R_GetCCallable("deSolve", "get_deSolve_gparms");')
  ret$add("  %s = %s_get_pointer(get_deSolve_gparms(), 1);",
          obj$name_pars, obj$info$base)
  ret$add("}")
  ret$add("void %s_deriv_ds(int *neq, double *%s, double *%s,",
          obj$info$base, TIME, STATE)
  ret$add("%sdouble *%s, double *%s, int *np) {",
          strrep(nchar(obj$info$base) + 15L), DSTATEDT, OUTPUT)
  ret$add("  %s_deriv(%s, *%s, %s, %s, %s);",
          obj$info$base, obj$name_pars, TIME, STATE, DSTATEDT, OUTPUT)
  ret$add("}")
  ret$get()
}

## I will need a different interface here using my ring buffer to do a
## discrete time model.  That will probably want to be written into
## this package, so I can exploit ring directly.  For now leave it...
odin_generate2_deriv_dde <- function(obj) {
  ret <- collector()
  ret$add("// dde interface")
  ret$add("void %s_deriv_dde(size_t n_eq, double %s, double *%s,",
          obj$info$base, TIME, STATE)
  ret$add("%sdouble *%s, void *%s) {",
          strrep(nchar(obj$info$base) + 17L), DSTATEDT, obj$name_pars)
  ret$add("  %s_deriv((%s*)%s, %s, %s, %s, NULL);",
          obj$info$base, obj$type_pars, obj$name_pars, TIME, STATE, DSTATEDT)
  ret$add("}")

  if (obj$info$has_output) {
    ## This needs working through because we don't want to get the
    ## output at every derivative calculation (that's wasteful), and
    ## because the dde solver does not actually stop at all the
    ## requested points it does need to be done in two stages.  So
    ## this will require some extra faff with generating output
    ## functions, which requires another trip through the DAG too.

    ## Here, we'll need to have done some output processing.
    ret$add("\nvoid %s_output_dde(size_t n_eq, double %s, double *%s,",
            obj$info$base, TIME, STATE)
    ret$add("%ssize_t dim_%s, double *%s, void *%s) {",
            strrep(nchar(obj$info$base) + 17L), OUTPUT, OUTPUT, obj$name_pars)
    ret$add("  %s_output((%s*)%s, %s, %s, %s);",
            obj$info$base, obj$type_pars, obj$name_pars, TIME, STATE, OUTPUT)
    ret$add("}")
  }
  ret$get()
}

## Helper functions here:
odin_generate2_vars <- function(obj, output = FALSE) {
  info <- obj$variable_info

  if (output) {
    used_eqs <- obj$info$eqs_used$output
  } else {
    used_eqs <-
      union(obj$info$eqs_used[[if (obj$info$discrete) "update" else "deriv"]],
            obj$info$eqs_used$output)
  }
  used <- info$order %in% used_eqs

  ret <- collector()
  i <- used & !info$is_array
  if (any(i)) {
    ret$add("double %s = %s[%s];", info$order[i], STATE,
            vcapply(info$offset_use[i], obj$rewrite))
  }
  i <- used & info$is_array
  if (any(i)) {
    ret$add("double *%s = %s%s;", info$order[i], STATE,
            vcapply(info$offset_use[i], odin_generate2_offset, obj$rewrite))
  }
  ret$get()
}

odin_generate2_unpack <- function(obj, type) {
  v <- switch(type,
              variables = "variable_info",
              output = "output_info",
              delays = "delay_info")
  info <- obj[[v]]
  if (any(info$is_array)) {
    sprintf("double *%s_%s = %s%s;",
            if (type == "output") "output" else obj$core$target_name,
            info$order[info$is_array],
            if (type == "output") OUTPUT else obj$core$state2,
            vcapply(info$offset_use[info$is_array], odin_generate2_offset,
                    obj$rewrite))
  } else {
    character(0)
  }
}

odin_generate2_offset <- function(x, rewrite) {
  if (identical(x, 0L)) {
    ""
  } else {
    sprintf(" + %s", rewrite(x))
  }
}
