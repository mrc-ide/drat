## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  error = FALSE)
lang_output <- function(language, text) {
  writeLines(c(paste0("```", language),  text, "```"))
}
tree <- function(path, header = path) {
  paste1 <- function(a, b) {
    paste(rep_len(a, length(b)), b)
  }
  indent <- function(x, files) {
    paste0(if (files) "| " else "  ", x)
  }
  is_directory <- function(x) {
    unname(file.info(x)[, "isdir"])
  }
  sort_files <- function(x) {
    i <- grepl("^[A-Z]", x)
    c(x[i], x[!i])
  }
  prefix_file <- "|--="
  prefix_dir  <- "|-+="
  files <- sort_files(dir(path))
  files_full <- file.path(path, files)
  isdir <- is_directory(files_full)
  ret <- as.list(c(paste1(prefix_dir, files[isdir]),
                   paste1(prefix_file, files[!isdir])))
  files_full <- c(files_full[isdir], files_full[!isdir])
  isdir <- c(isdir[isdir], isdir[!isdir])
  n <- length(ret)
  if (n > 0) {
    ret[[n]] <- sub("|", "\\", ret[[n]], fixed = TRUE)
    tmp <- lapply(which(isdir), function(i)
      c(ret[[i]], indent(tree(files_full[[i]], NULL), !all(isdir))))
    ret[isdir] <- tmp
  }
  c(header, unlist(ret))
}

## ---- results = "asis", echo = FALSE------------------------------------------
path <- system.file("examples/simple.json", package = "traduire",
                    mustWork = TRUE)
lang_output("json", readLines(path))

## -----------------------------------------------------------------------------
tr <- traduire::i18n(path, "en")
tr

## -----------------------------------------------------------------------------
tr$t("hello")

## -----------------------------------------------------------------------------
tr$t("hello", language = "fr")

## -----------------------------------------------------------------------------
tr$t("interpolate", list(what = "i18next", how = "easy"),
     language = "en")
tr$t("interpolate", list(what = "i18next", how = "facile"),
     language = "fr")

## ---- results = "asis", echo = FALSE------------------------------------------
path_validation <- system.file("examples/validation.json",
                               package = "traduire", mustWork = TRUE)
lang_output("json", readLines(path_validation))

## -----------------------------------------------------------------------------
tr <- traduire::i18n(path_validation)

## -----------------------------------------------------------------------------
tr$t("nocols", list(missing = "A"), count = 1)
tr$t("nocols", list(missing = "A, B"), count = 2)

## -----------------------------------------------------------------------------
tr$t("nocols", list(missing = "A"), count = 1, language = "fr")
tr$t("nocols", list(missing = "A, B"), count = 2, language = "fr")

## -----------------------------------------------------------------------------
path_hello <- system.file("hello/inst/traduire.json", package = "traduire")

## -----------------------------------------------------------------------------
tr <- traduire::i18n(path_hello, fallback = "it")
tr$t("hello", language = "unknown")

## -----------------------------------------------------------------------------
tr <- traduire::i18n(path_hello, fallback = c("a", "b", "de"))
tr$t("hello", language = "unknown")

## -----------------------------------------------------------------------------
tr <- traduire::i18n(path_hello, fallback = list(co = "fr", "default" = "en"))
tr$t("hello", language = "co")
tr$t("hello", language = "unknown")

## -----------------------------------------------------------------------------
string <- '{
  "id": "area_scope",
  "label": "t_(element_label)",
  "type": "multiselect",
  "description": "t_(element_description)"
}'

## -----------------------------------------------------------------------------
translations <- '{
    "en": {
        "translation": {
            "element_label": "Country",
            "element_description": "Select your countries"
        }
    },
    "fr": {
        "translation": {
            "element_label": "Payes",
            "element_description": "Sélectionnez vos payes"
        }
    }
}'

## -----------------------------------------------------------------------------
tr <- traduire::i18n(translations)

## -----------------------------------------------------------------------------
writeLines(tr$replace(string))

## -----------------------------------------------------------------------------
writeLines(tr$replace(string, language = "fr"))

## ---- results = "asis", echo = FALSE------------------------------------------
path_hello <- system.file("hello", package = "traduire", mustWork = TRUE)
lang_output("plain", tree(path_hello, "hello"))

## ---- results = "asis", echo = FALSE------------------------------------------
content <- readLines(file.path(path_hello, "R", "hello.R"))
lang_output("r", content[!grepl("^#", content)])

## ---- results = "asis", echo = FALSE------------------------------------------
content <- readLines(file.path(path_hello, "inst", "plumber.R"))
lang_output("r", content)

## ---- results = "asis", echo = FALSE------------------------------------------
content <- readLines(file.path(path_hello, "R", "api.R"))
lang_output("r", content[!grepl("^#", content)])

## ---- results = "asis", echo = FALSE------------------------------------------
path <- system.file("examples/simple.json", package = "traduire",
                    mustWork = TRUE)
lang_output("json", readLines(path))

## ---- results = "asis", echo = FALSE------------------------------------------
path <- system.file("examples/namespaces.json", package = "traduire",
                    mustWork = TRUE)
lang_output("json", readLines(path))

## -----------------------------------------------------------------------------
tr <- traduire::i18n(path, default_namespace = "common")

## -----------------------------------------------------------------------------
tr$t("hello")

## -----------------------------------------------------------------------------
tr$t("common:hello", language = "fr")
tr$t("login:username", language = "fr")

## ---- results = "asis", echo = FALSE------------------------------------------
path <- system.file("examples/structured", package = "traduire",
                    mustWork = TRUE)
lang_output("plain", tree(path, "structured"))

## ---- results = "asis", echo = FALSE------------------------------------------
lang_output("json", readLines(file.path(path, "en-login.json")))

## -----------------------------------------------------------------------------
obj <- traduire::i18n(NULL)
obj$add_resource_bundle("en", "common", file.path(path, "en-common.json"))
obj$add_resource_bundle("en", "login", file.path(path, "en-login.json"))
obj$add_resource_bundle("fr", "common", file.path(path, "fr-common.json"))
obj$add_resource_bundle("fr", "login", file.path(path, "fr-login.json"))
obj$t("login:password", language = "fr")

## -----------------------------------------------------------------------------
obj <- traduire::i18n(NULL)
for (language in c("en", "fr")) {
  for (namespace in c("common", "login")) {
    bundle <- file.path(path, sprintf("%s-%s.json", language, namespace))
    obj$add_resource_bundle(language, namespace, bundle)
  }
}
obj$t("login:password", language = "fr")

## -----------------------------------------------------------------------------
pattern <- file.path(path, "{language}-{namespace}.json")
obj <- traduire::i18n(NULL, resource_pattern = pattern,
                      languages = c("en", "fr"),
                      namespaces = c("common", "login"))
obj$t("login:password", language = "fr")

