library(testthat)
library(traduire)

test_check("traduire")
