// [[odin.dust::register]]
template <typename T>
double cumulative_to_i(size_t i, T y) {
  double n = 0;
  for (size_t j = 0; j < i; ++j) {
    n += y[j];
  }
  return n;
}
