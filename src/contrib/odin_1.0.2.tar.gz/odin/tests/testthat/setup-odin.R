prepare_run_tests()
