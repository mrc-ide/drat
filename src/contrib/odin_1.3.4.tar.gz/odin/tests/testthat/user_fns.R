squarepulse <- function(t, t0, t1) {
  t >= t0 && t < t1
}
