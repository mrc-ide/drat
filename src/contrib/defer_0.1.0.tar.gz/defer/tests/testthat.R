library(testthat)
library(defer)

test_check("defer")
