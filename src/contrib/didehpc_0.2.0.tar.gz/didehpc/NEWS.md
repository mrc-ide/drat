# didehpc 0.2.0

* Support for R 3.4.x and 3.5.x ([#54](https://github.com/mrc-ide/didehpc/issues/54))
* Better detection of windows mounts ([#52](https://github.com/mrc-ide/didehpc/pull/52)) by `@weshinsley`
* Documentation improvements ([#47](https://github.com/mrc-ide/didehpc/pull/47)) by `@weshinsley`

# didehpc 0.1.6

* Fix mount-point detection failure with wmic occurring on some Windows machines.

# didehpc 0.1.5

* Check what resources a user has on login ([#50](https://github.com/mrc-ide/didehpc/issues/50))

# didehpc 0.1.4

* Support for machines set up to use `qdrive` ([#48](https://github.com/mrc-ide/didehpc/issues/48))
