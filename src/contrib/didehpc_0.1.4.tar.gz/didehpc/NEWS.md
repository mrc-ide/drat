# didehpc 0.1.4

* Support for machines set up to use `qdrive` ([#48](https://github.com/mrc-ide/didehpc/issues/48))
