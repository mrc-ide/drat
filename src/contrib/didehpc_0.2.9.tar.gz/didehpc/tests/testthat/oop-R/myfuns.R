read <- function() {
  read.csv("oop-data/foo.csv")
}
