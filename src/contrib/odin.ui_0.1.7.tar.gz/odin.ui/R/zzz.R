## These should be made configurable later, but are set to _something_
## to try and stop the model taking down the server when too many are
## requested.
##
## The biggest drain is plotting things though, and that's client side.
MAX_REPLICATES_PARAMETER_PLOT <- 5000
MAX_REPLICATES_MODEL <- 500
