initial(y[, , ]) <- 1
deriv(y[, , ]) <- y[i, j, k] * 0.1
dim(y) <- c(2, 3, 4)
