deriv(y) <- 2
initial(y) <- 1
output(z) <- a * 2
a <- t + y
