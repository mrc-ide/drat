initial(x) <- 1
update(x) <- x + 1
