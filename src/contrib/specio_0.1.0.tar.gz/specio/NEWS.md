## 0.1.0

Add extract_population and extract_hiv_population methods
