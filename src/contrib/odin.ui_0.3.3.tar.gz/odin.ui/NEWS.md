## 0.1.3

* UI tweaks for better automated layout

## 0.1.2

* Allow time scaling ([#16](https://github.com/mrc-ide/odin.ui/issues/16))

## 0.1.1

* Fix log-scale in ODE plots ([#15](https://github.com/mrc-ide/odin.ui/issues/15))
* Set reasonable maximum replicate values

## 0.1.0

* First internal (pre) release
